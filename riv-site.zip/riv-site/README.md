# Site d'itinéraires RIV : moteur de calcul (étape 1)

Calcul de trajets en bus RIV (Ploërmel Communauté) : direct ou avec un changement,
« partir à » / « arriver à », jours sans service, marche depuis une adresse.
Aucune dépendance. Le moteur tourne dans le navigateur comme sous Node.

## Contenu
- `js/engine.js` : le moteur (données en entrée, trajets en sortie, aucun texte d'interface).
- `data/riv.json` : horaires RIV, généré à partir du GTFS (ne pas modifier à la main).
- `data/quais_vers_arrets.csv` : noms d'arrêts validés (un quai du GTFS -> un arrêt affiché + commune).
- `data/gtfs/RIV_mini_gtfs.zip` : extrait du GTFS RIV (copie de référence).
- `scripts/build_data.py` : régénère `data/riv.json` depuis un GTFS.
- `scripts/exemples.mjs` : affiche des trajets types pour relecture.
- `tests/engine.test.mjs` : tests (recoupement avec le feuillet horaire, calendrier, marche, changements).

## Commandes (Python 3 et Node 18+ suffisent)
    python3 scripts/build_data.py chemin/vers/gtfs.zip   # régénère data/riv.json
    node tests/engine.test.mjs                           # lance les tests
    node scripts/exemples.mjs                            # trajets types

## Chaque rentrée (septembre)
1. Récupérer le nouveau GTFS (export régional ou extrait RIV).
2. `python3 scripts/build_data.py nouveau_gtfs.zip`
3. Si le script liste des quais absents de `data/quais_vers_arrets.csv` : ajouter une ligne par quai
   (`arret_id`, `nom_affiche`, `commune`, `nom_complet`), puis relancer.
4. `node tests/engine.test.mjs`. Les tests qui citent des horaires du feuillet (« Ligne 1 : Réhumpol 07:41 … »)
   doivent être mis à jour avec le nouveau feuillet : un échec ici est normal si les horaires ont changé.
5. Relire `node scripts/exemples.mjs`, puis publier.

## Réglages (début de `js/engine.js`, objet `CONFIG`)
vitesse de marche (4 km/h), coefficient de détour (1,3), marge à l'arrêt (0 min : l'interface conseille d'arriver
5 min avant), changement minimal (5 min), seuil « correspondance courte » (8 min), « longue attente » (1 h),
plafond de marche (40 min), limite de marche par défaut (15 min).
